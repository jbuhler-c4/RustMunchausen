#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

uintptr_t add(uintptr_t left, uintptr_t right);

int32_t (*rust_munchausen_numbers(void))[4];
